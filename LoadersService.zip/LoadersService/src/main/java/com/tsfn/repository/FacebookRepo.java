package com.tsfn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tsfn.model.Facebook;

public interface FacebookRepo extends JpaRepository<Facebook, Integer>{

}
