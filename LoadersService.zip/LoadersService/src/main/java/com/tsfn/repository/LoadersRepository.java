package com.tsfn.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.tsfn.model.Facebook;

public interface LoadersRepository extends JpaRepository<Facebook, Integer> {
		
	 	
}
